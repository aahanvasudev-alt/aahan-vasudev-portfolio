import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

// ════════════════════════════════════════════════════════════════════════════════
// SEQUENCE 1: THE OPENING STATEMENT (PHILOSOPHICAL PREMISE)
// ════════════════════════════════════════════════════════════════════════════════
interface StatementLine {
  id: string;
  text: string;
  align: 'left' | 'right' | 'between';
  tier: 'lead' | 'pivot' | 'monument' | 'echo' | 'climax';
  accent?: boolean;
}

const SEQUENCE_1_LINES: StatementLine[] = [
  {
    id: 'line-lead',
    text: "I DON'T JUST WANT TO TELL STORIES.",
    align: 'left',
    tier: 'lead',
  },
  {
    id: 'line-pivot',
    text: 'I WANT TO CREATE',
    align: 'left',
    tier: 'pivot',
  },
  {
    id: 'line-monument',
    text: 'EXPERIENCES',
    align: 'right',
    tier: 'monument',
  },
  {
    id: 'line-echo',
    text: 'THAT STAY LONG AFTER',
    align: 'left',
    tier: 'echo',
  },
  {
    id: 'line-climax',
    text: 'THE FRAME DISAPPEARS.',
    align: 'right',
    tier: 'climax',
    accent: true,
  },
];

// ════════════════════════════════════════════════════════════════════════════════
// SEQUENCE 2: THE RESOLUTION (VISUAL MANIFESTO)
// ════════════════════════════════════════════════════════════════════════════════
interface ResolutionLine {
  id: string;
  text: string;
  tier: 'remains' | 'light' | 'fades' | 'emotion';
  accent?: boolean;
}

const SEQUENCE_2_LINES: ResolutionLine[] = [
  {
    id: 'seq2-remains',
    text: 'WHAT REMAINS',
    tier: 'remains',
  },
  {
    id: 'seq2-light',
    text: 'WHEN THE LIGHT',
    tier: 'light',
  },
  {
    id: 'seq2-fades',
    text: 'FADES',
    tier: 'fades',
    accent: true,
  },
  {
    id: 'seq2-emotion',
    text: 'IS THE EMOTION.',
    tier: 'emotion',
  },
];

export const IntroStatement: React.FC = () => {
  const containerRef = useRef<HTMLElement | null>(null);
  const pinnedStageRef = useRef<HTMLDivElement | null>(null);
  const scene1Ref = useRef<HTMLDivElement | null>(null);
  const scene2Ref = useRef<HTMLDivElement | null>(null);
  const spatialBackdropRef = useRef<HTMLDivElement | null>(null);
  const cameraPlanesRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const stage = pinnedStageRef.current;
    const scene1 = scene1Ref.current;
    const scene2 = scene2Ref.current;
    const spatialBackdrop = spatialBackdropRef.current;
    const cameraPlanes = cameraPlanesRef.current;

    if (!stage || !scene1 || !scene2) return;

    const prefersReducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    // ════════════════════════════════════════════════════════════════════════════
    // 1. MASTER GSAP SCROLLTRIGGER CHOREOGRAPHY
    // Single unified pinned timeline spanning 520% scroll runway.
    // Deliberate progressive entrance for Sequence 1, spacious pacing for Sequence 2,
    // intentional typography spacing with zero overlap, and clean bidirectional scrub.
    // ════════════════════════════════════════════════════════════════════════════
    const ctx = gsap.context(() => {
      if (prefersReducedMotion) {
        // Simplified accessible crossfade for users who prefer reduced motion
        gsap.to(scene1, {
          autoAlpha: 0,
          scrollTrigger: {
            trigger: stage,
            start: 'top top',
            end: '+=70%',
            scrub: true,
          },
        });
        gsap.fromTo(
          scene2,
          { autoAlpha: 0 },
          {
            autoAlpha: 1,
            scrollTrigger: {
              trigger: stage,
              start: 'top -30%',
              end: '+=70%',
              scrub: true,
            },
          }
        );
        return;
      }

      // Master Timeline pinned across 520% scroll runway for spacious, cinematic pacing
      const masterTl = gsap.timeline({
        scrollTrigger: {
          trigger: stage,
          start: 'top top',
          end: '+=520%',
          pin: true,
          scrub: 0.85,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });

      // Target character groups in Sequence 1
      const leadChars = scene1.querySelectorAll('.char-line-lead .char-outer');
      const pivotChars = scene1.querySelectorAll('.char-line-pivot .char-outer');
      const monumentChars = scene1.querySelectorAll('.char-line-monument .char-outer');
      const echoChars = scene1.querySelectorAll('.char-line-echo .char-outer');
      const climaxChars = scene1.querySelectorAll('.char-line-climax .char-outer');
      const metaElements1 = scene1.querySelectorAll('.meta-element-1');

      // Target character groups in Sequence 2
      const remainsChars = scene2.querySelectorAll('.char-seq2-remains .char-outer');
      const lightChars = scene2.querySelectorAll('.char-seq2-light .char-outer');
      const fadesChars = scene2.querySelectorAll('.char-seq2-fades .char-outer');
      const emotionChars = scene2.querySelectorAll('.char-seq2-emotion .char-outer');
      const s2Headline = scene2.querySelector('.seq2-headline');
      const s2Quote = scene2.querySelector('.seq2-quote');
      const s2Attribution = scene2.querySelector('.seq2-attribution');

      // ────────────────────────────────────────────────────────────────────────
      // EXPLICIT INITIAL STATE DEFINITIONS
      // Sequence 1 letters start below their masked bounds in 3D depth.
      // The visitor will actually WITNESS the typography being constructed!
      // ────────────────────────────────────────────────────────────────────────
      gsap.set(scene1, { autoAlpha: 1, pointerEvents: 'auto' });
      gsap.set(scene2, { autoAlpha: 0, pointerEvents: 'none' });

      // Sequence 1 initial states: hidden below lines with perspective tilt
      gsap.set(leadChars, {
        autoAlpha: 0,
        yPercent: 120,
        rotateX: -35,
        z: -160,
      });

      gsap.set(pivotChars, {
        autoAlpha: 0,
        yPercent: 120,
        rotateX: -35,
        z: -140,
      });

      gsap.set(monumentChars, {
        autoAlpha: 0,
        scale: 0.65,
        yPercent: 140,
        z: -250,
        rotateX: -45,
      });

      gsap.set(echoChars, {
        autoAlpha: 0,
        yPercent: 120,
        rotateX: -30,
        z: -140,
      });

      gsap.set(climaxChars, {
        autoAlpha: 0,
        yPercent: 120,
        rotateX: -35,
        z: -160,
      });

      gsap.set(metaElements1, {
        autoAlpha: 0,
        y: (i) => (i === 0 ? -20 : 20),
      });

      // Sequence 2 initial character setups: positioned for kinetic assembly
      gsap.set(remainsChars, {
        autoAlpha: 0,
        z: -260,
        scale: 1.5,
        yPercent: 120,
        rotateX: 45,
      });

      gsap.set(lightChars, {
        autoAlpha: 0,
        xPercent: -45,
        z: -160,
        rotateY: -30,
        scale: 0.8,
      });

      gsap.set(fadesChars, {
        autoAlpha: 0,
        scale: 2.2,
        z: 220,
        yPercent: -50,
        rotateX: -25,
      });

      gsap.set(emotionChars, {
        autoAlpha: 0,
        z: 360,
        yPercent: 90,
        rotateX: -40,
        scale: 0.82,
      });

      if (s2Headline) gsap.set(s2Headline, { autoAlpha: 0, y: -20 });
      if (s2Quote) gsap.set(s2Quote, { autoAlpha: 0, y: 25 });
      if (s2Attribution) gsap.set(s2Attribution, { autoAlpha: 0, y: 20 });
      if (spatialBackdrop) gsap.set(spatialBackdrop, { autoAlpha: 0, scale: 0.94 });

      // ────────────────────────────────────────────────────────────────────────
      // CHAPTER 1: SEQUENCE 1 DELIBERATE ENTRANCE (Fixes Task 1)
      // Progress 0.00 -> 0.22
      // Words enter progressively through masking and clipping as the user scrolls.
      // ────────────────────────────────────────────────────────────────────────
      masterTl.addLabel('seq1-entrance-start', 0.0);

      // Metadata bars emerge
      masterTl.to(
        metaElements1,
        {
          autoAlpha: 1,
          y: 0,
          ease: 'power2.out',
          duration: 0.05,
        },
        0.01
      );

      // Line 1: "I DON'T JUST WANT TO TELL STORIES." assembles from depth
      masterTl.to(
        leadChars,
        {
          autoAlpha: 1,
          yPercent: 0,
          rotateX: 0,
          z: 0,
          stagger: 0.006,
          ease: 'power3.out',
          duration: 0.08,
        },
        0.02
      );

      // Line 2: "I WANT TO CREATE" slides up into position
      masterTl.to(
        pivotChars,
        {
          autoAlpha: 1,
          yPercent: 0,
          rotateX: 0,
          z: 0,
          stagger: 0.007,
          ease: 'power3.out',
          duration: 0.08,
        },
        0.05
      );

      // Line 3: Monolithic "EXPERIENCES" surges forward and scales into place
      masterTl.to(
        monumentChars,
        {
          autoAlpha: 1,
          scale: 1,
          yPercent: 0,
          rotateX: 0,
          z: 0,
          stagger: 0.012,
          ease: 'power3.out',
          duration: 0.10,
        },
        0.08
      );

      // Line 4: "THAT STAY LONG AFTER" assembles
      masterTl.to(
        echoChars,
        {
          autoAlpha: 1,
          yPercent: 0,
          rotateX: 0,
          z: 0,
          stagger: 0.006,
          ease: 'power3.out',
          duration: 0.08,
        },
        0.12
      );

      // Line 5: "THE FRAME DISAPPEARS." snaps into place with golden accent
      masterTl.to(
        climaxChars,
        {
          autoAlpha: 1,
          yPercent: 0,
          rotateX: 0,
          z: 0,
          stagger: 0.007,
          ease: 'power3.out',
          duration: 0.09,
        },
        0.14
      );

      // ────────────────────────────────────────────────────────────────────────
      // SEQUENCE 1 ASSEMBLED HOLD (0.22 -> 0.28)
      // The fully formed typographic composition holds in pristine stillness.
      // Full cursor interactivity is available.
      // ────────────────────────────────────────────────────────────────────────
      masterTl.addLabel('seq1-assembled-hold', 0.22);

      // ────────────────────────────────────────────────────────────────────────
      // SEQUENCE 1 3D DISPLACEMENT (0.28 -> 0.38)
      // Words separate across defined dimensional paths.
      // ────────────────────────────────────────────────────────────────────────
      masterTl.addLabel('seq1-displacement', 0.28);

      masterTl.to(
        metaElements1,
        {
          autoAlpha: 0,
          y: (i) => (i === 0 ? -25 : 25),
          ease: 'power2.inOut',
          duration: 0.06,
        },
        0.28
      );

      masterTl.to(
        leadChars,
        {
          z: -340,
          y: -80,
          autoAlpha: 0.25,
          rotateX: 35,
          stagger: 0.005,
          ease: 'power2.inOut',
          duration: 0.10,
        },
        0.29
      );

      masterTl.to(
        pivotChars,
        {
          z: -200,
          y: 70,
          rotateX: -30,
          autoAlpha: 0.25,
          stagger: 0.006,
          ease: 'power2.inOut',
          duration: 0.10,
        },
        0.30
      );

      monumentChars.forEach((charEl, idx) => {
        const isOdd = idx % 2 === 1;
        masterTl.to(
          charEl,
          {
            z: isOdd ? 260 : -180,
            y: isOdd ? -50 : 60,
            scale: isOdd ? 1.4 : 0.85,
            rotateY: isOdd ? 18 : -18,
            ease: 'power2.inOut',
            duration: 0.11,
          },
          0.30 + idx * 0.004
        );
      });

      masterTl.to(
        echoChars,
        {
          x: (i) => (i - echoChars.length / 2) * 14,
          z: -220,
          autoAlpha: 0.3,
          ease: 'power2.inOut',
          duration: 0.10,
        },
        0.31
      );

      masterTl.to(
        climaxChars,
        {
          x: (i) => 30 + i * 8,
          rotateZ: -4,
          autoAlpha: 0.4,
          stagger: 0.005,
          ease: 'power2.inOut',
          duration: 0.10,
        },
        0.31
      );

      // ────────────────────────────────────────────────────────────────────────
      // SEQUENCE 1 FLY-THROUGH & 100% COMPLETE EXIT (0.38 -> 0.48)
      // "EXPERIENCES" swells beyond viewport; all remaining letters dissolve to black.
      // ────────────────────────────────────────────────────────────────────────
      masterTl.addLabel('seq1-exit', 0.38);

      monumentChars.forEach((charEl, idx) => {
        masterTl.to(
          charEl,
          {
            scale: 3.8,
            z: 950,
            autoAlpha: 0,
            rotateX: 20,
            ease: 'power3.in',
            duration: 0.10,
          },
          0.38 + idx * 0.005
        );
      });

      masterTl.to(
        [leadChars, pivotChars, echoChars, climaxChars],
        {
          autoAlpha: 0,
          scale: 0.4,
          z: -700,
          ease: 'power2.in',
          duration: 0.09,
        },
        0.39
      );

      if (spatialBackdrop) {
        masterTl.to(
          spatialBackdrop,
          {
            autoAlpha: 0.8,
            scale: 1,
            ease: 'power2.out',
            duration: 0.08,
          },
          0.39
        );
        masterTl.to(
          spatialBackdrop,
          {
            autoAlpha: 0,
            scale: 1.08,
            ease: 'power2.in',
            duration: 0.07,
          },
          0.47
        );
      }

      if (cameraPlanes) {
        masterTl.fromTo(
          cameraPlanes,
          { rotateX: 0, rotateY: 0 },
          {
            rotateX: 6,
            rotateY: -5,
            ease: 'power1.inOut',
            duration: 0.10,
          },
          0.39
        );
      }

      // Explicit clearance of Sequence 1: no ghost elements can ever remain
      masterTl.to(
        scene1,
        {
          autoAlpha: 0,
          pointerEvents: 'none',
          duration: 0.02,
        },
        0.48
      );

      // ────────────────────────────────────────────────────────────────────────
      // CHAPTER 2: SEQUENCE 2 EXPANDED, SPACIOUS KINETIC CHOREOGRAPHY (Fixes Task 2 & 3)
      // Progress 0.50 -> 0.95
      // Substantial scroll distance dedicated to this visual chapter.
      // Each line has intentional vertical spacing, distinct kinetic identity, and zero collision.
      // ────────────────────────────────────────────────────────────────────────
      masterTl.addLabel('seq2-chapter-start', 0.50);

      // Sequence 2 container mounts cleanly at 0.50
      masterTl.to(
        scene2,
        {
          autoAlpha: 1,
          pointerEvents: 'auto',
          duration: 0.02,
        },
        0.50
      );

      // Top indicator pill arrives
      if (s2Headline) {
        masterTl.to(
          s2Headline,
          {
            autoAlpha: 1,
            y: 0,
            ease: 'power2.out',
            duration: 0.06,
          },
          0.52
        );
      }

      // 1. WHAT REMAINS (0.54 -> 0.63)
      // Letters assemble from spatial depth with optical kerning
      masterTl.to(
        remainsChars,
        {
          autoAlpha: 1,
          z: 0,
          scale: 1,
          yPercent: 0,
          rotateX: 0,
          stagger: 0.015,
          ease: 'power3.out',
          duration: 0.09,
        },
        0.54
      );

      // 2. WHEN THE LIGHT (0.62 -> 0.71)
      // Perspective shearing sweep into crisp alignment with generous vertical breathing room
      masterTl.to(
        lightChars,
        {
          autoAlpha: 1,
          xPercent: 0,
          z: 0,
          rotateY: 0,
          scale: 1,
          stagger: 0.012,
          ease: 'power3.out',
          duration: 0.09,
        },
        0.62
      );

      // 3. FADES (0.70 -> 0.79)
      // Standalone dramatic accent word: transforms from optical expansion with golden glow
      masterTl.to(
        fadesChars,
        {
          autoAlpha: 1,
          scale: 1,
          z: 0,
          yPercent: 0,
          rotateX: 0,
          stagger: 0.018,
          ease: 'back.out(1.4)',
          duration: 0.10,
        },
        0.70
      );

      // 4. IS THE EMOTION. (0.78 -> 0.88)
      // The Grand Climax — Monolithic characters surge forward without overlapping preceding lines
      masterTl.to(
        emotionChars,
        {
          autoAlpha: 1,
          z: 0,
          yPercent: 0,
          rotateX: 0,
          scale: 1,
          stagger: 0.016,
          ease: 'power4.out',
          duration: 0.11,
        },
        0.78
      );

      // Reset camera plane for locked final presentation
      if (cameraPlanes) {
        masterTl.to(
          cameraPlanes,
          {
            rotateX: 0,
            rotateY: 0,
            ease: 'power2.out',
            duration: 0.08,
          },
          0.78
        );
      }

      // 5. Authentic Quote & Attribution lockup reveal beneath
      if (s2Quote) {
        masterTl.to(
          s2Quote,
          {
            autoAlpha: 1,
            y: 0,
            ease: 'power2.out',
            duration: 0.06,
          },
          0.84
        );
      }

      if (s2Attribution) {
        masterTl.to(
          s2Attribution,
          {
            autoAlpha: 1,
            y: 0,
            ease: 'power2.out',
            duration: 0.06,
          },
          0.87
        );
      }

      // ────────────────────────────────────────────────────────────────────────
      // SEQUENCE 2 EXTENDED RESOLVED HOLD (0.88 -> 0.95)
      // Substantial reading and cursor exploration window.
      // Every line has deliberate spacing and zero overlap.
      // ────────────────────────────────────────────────────────────────────────
      masterTl.addLabel('seq2-resolved-hold', 0.88);

      // ────────────────────────────────────────────────────────────────────────
      // TRANSITION INTO PROJECTS SHOWREEL (0.95 -> 1.00)
      // Sequence 2 gently lifts away, delivering the user seamlessly into Projects.
      // ────────────────────────────────────────────────────────────────────────
      masterTl.to(
        scene2,
        {
          yPercent: -15,
          autoAlpha: 0,
          ease: 'power2.in',
          duration: 0.05,
        },
        0.95
      );

      masterTl.addLabel('section-end', 1.0);
    }, containerRef);

    // ════════════════════════════════════════════════════════════════════════════
    // 2. UNIFIED CURSOR-RESPONSIVE TYPOGRAPHY PHYSICS ENGINE
    // Active across BOTH Sequence 1 and Sequence 2.
    // Letters magnetic repulsion, 3D lift, perspective tilt, and spring settling.
    // ════════════════════════════════════════════════════════════════════════════
    const physicsNodes = stage.querySelectorAll<HTMLElement>('.char-physics');
    if (physicsNodes.length === 0 || prefersReducedMotion) {
      return () => ctx.revert();
    }

    interface PhysicsParticle {
      el: HTMLElement;
      sceneEl: HTMLElement | null;
      originX: number;
      originY: number;
      curX: number;
      curY: number;
      curZ: number;
      curRotX: number;
      curRotY: number;
      curRotZ: number;
      curScale: number;
      tarX: number;
      tarY: number;
      tarZ: number;
      tarRotX: number;
      tarRotY: number;
      tarRotZ: number;
      tarScale: number;
      vx: number;
      vy: number;
      vz: number;
      vRotX: number;
      vRotY: number;
      vRotZ: number;
      vScale: number;
    }

    let particles: PhysicsParticle[] = [];

    // Cache character center coordinates relative to the pinned stage
    const measureParticles = () => {
      const stageRect = stage.getBoundingClientRect();
      particles = Array.from(physicsNodes).map((el) => {
        const rect = el.getBoundingClientRect();
        const sceneEl = el.closest('.scene-container') as HTMLElement | null;
        return {
          el,
          sceneEl,
          originX: rect.left + rect.width / 2 - stageRect.left,
          originY: rect.top + rect.height / 2 - stageRect.top,
          curX: 0,
          curY: 0,
          curZ: 0,
          curRotX: 0,
          curRotY: 0,
          curRotZ: 0,
          curScale: 1,
          tarX: 0,
          tarY: 0,
          tarZ: 0,
          tarRotX: 0,
          tarRotY: 0,
          tarRotZ: 0,
          tarScale: 1,
          vx: 0,
          vy: 0,
          vz: 0,
          vRotX: 0,
          vRotY: 0,
          vRotZ: 0,
          vScale: 0,
        };
      });
    };

    // Initial measurement
    measureParticles();

    // Re-measure on window resize or ScrollTrigger refresh
    const handleResize = () => measureParticles();
    window.addEventListener('resize', handleResize, { passive: true });
    ScrollTrigger.addEventListener('refresh', handleResize);

    // Mouse coordinates relative to stage
    let mouseRelX = -99999;
    let mouseRelY = -99999;
    let isCursorInBounds = false;
    let animFrameId: number;

    const handlePointerMove = (e: MouseEvent) => {
      const stageRect = stage.getBoundingClientRect();
      const inX = e.clientX >= stageRect.left && e.clientX <= stageRect.right;
      const inY = e.clientY >= stageRect.top && e.clientY <= stageRect.bottom;

      if (inX && inY) {
        mouseRelX = e.clientX - stageRect.left;
        mouseRelY = e.clientY - stageRect.top;
        isCursorInBounds = true;
      } else {
        isCursorInBounds = false;
        mouseRelX = -99999;
        mouseRelY = -99999;
      }
    };

    const handlePointerLeave = () => {
      isCursorInBounds = false;
      mouseRelX = -99999;
      mouseRelY = -99999;
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    document.addEventListener('mouseleave', handlePointerLeave);

    // Mobile / touch support
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const touch = e.touches[0];
        const stageRect = stage.getBoundingClientRect();
        mouseRelX = touch.clientX - stageRect.left;
        mouseRelY = touch.clientY - stageRect.top;
        isCursorInBounds = true;
      }
    };

    const handleTouchEnd = () => {
      isCursorInBounds = false;
      mouseRelX = -99999;
      mouseRelY = -99999;
    };

    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd, { passive: true });

    // Physics constants
    const RADIUS = 180; // Proximity threshold in pixels
    const MAX_PUSH = 32; // Max displacement in pixels
    const SPRING = 0.14; // Spring stiffness
    const DAMPING = 0.82; // Velocity damping factor

    // Continuous 60/120fps animation frame loop
    const tickPhysics = () => {
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Check if character's parent scene is visible. If hidden, skip physics to save GPU
        const isSceneVisible =
          p.sceneEl &&
          p.sceneEl.style.visibility !== 'hidden' &&
          p.sceneEl.style.opacity !== '0';

        if (isCursorInBounds && isSceneVisible) {
          const dx = p.originX - mouseRelX;
          const dy = p.originY - mouseRelY;
          const dist = Math.hypot(dx, dy);

          if (dist < RADIUS && dist > 0.001) {
            // Cubic falloff for organic tactile feel
            const falloff = Math.pow(1 - dist / RADIUS, 2.2);
            const dirX = dx / dist;
            const dirY = dy / dist;

            p.tarX = dirX * MAX_PUSH * falloff;
            p.tarY = dirY * MAX_PUSH * falloff;
            p.tarZ = 45 * falloff; // Letters lift towards the viewer in 3D
            p.tarRotY = dirX * 16 * falloff;
            p.tarRotX = -dirY * 16 * falloff;
            p.tarRotZ = -dirX * 10 * falloff;
            p.tarScale = 1 + 0.14 * falloff;
          } else {
            p.tarX = 0;
            p.tarY = 0;
            p.tarZ = 0;
            p.tarRotX = 0;
            p.tarRotY = 0;
            p.tarRotZ = 0;
            p.tarScale = 1;
          }
        } else {
          p.tarX = 0;
          p.tarY = 0;
          p.tarZ = 0;
          p.tarRotX = 0;
          p.tarRotY = 0;
          p.tarRotZ = 0;
          p.tarScale = 1;
        }

        // Spring acceleration & velocity integration
        p.vx = (p.vx + (p.tarX - p.curX) * SPRING) * DAMPING;
        p.curX += p.vx;

        p.vy = (p.vy + (p.tarY - p.curY) * SPRING) * DAMPING;
        p.curY += p.vy;

        p.vz = (p.vz + (p.tarZ - p.curZ) * SPRING) * DAMPING;
        p.curZ += p.vz;

        p.vRotX = (p.vRotX + (p.tarRotX - p.curRotX) * SPRING) * DAMPING;
        p.curRotX += p.vRotX;

        p.vRotY = (p.vRotY + (p.tarRotY - p.curRotY) * SPRING) * DAMPING;
        p.curRotY += p.vRotY;

        p.vRotZ = (p.vRotZ + (p.tarRotZ - p.curRotZ) * SPRING) * DAMPING;
        p.curRotZ += p.vRotZ;

        p.vScale = (p.vScale + (p.tarScale - p.curScale) * SPRING) * DAMPING;
        p.curScale += p.vScale;

        // Efficient resting check to bypass styles when static
        const isResting =
          Math.abs(p.curX) < 0.04 &&
          Math.abs(p.curY) < 0.04 &&
          Math.abs(p.curZ) < 0.04 &&
          Math.abs(p.curRotZ) < 0.04 &&
          Math.abs(p.curScale - 1) < 0.003;

        if (isResting) {
          if (p.el.style.transform !== '') {
            p.el.style.transform = '';
          }
        } else {
          p.el.style.transform = `translate3d(${p.curX.toFixed(2)}px, ${p.curY.toFixed(2)}px, ${p.curZ.toFixed(2)}px) rotateX(${p.curRotX.toFixed(2)}deg) rotateY(${p.curRotY.toFixed(2)}deg) rotateZ(${p.curRotZ.toFixed(2)}deg) scale(${p.curScale.toFixed(3)})`;
        }
      }

      animFrameId = requestAnimationFrame(tickPhysics);
    };

    animFrameId = requestAnimationFrame(tickPhysics);

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('mousemove', handlePointerMove);
      document.removeEventListener('mouseleave', handlePointerLeave);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('resize', handleResize);
      ScrollTrigger.removeEventListener('refresh', handleResize);
      ctx.revert();
    };
  }, []);

  return (
    <section
      ref={containerRef}
      className="relative z-[3] bg-black text-white w-full overflow-hidden select-none"
      aria-label="Director Statement Sequence"
    >
      {/* Background Film Grain Overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.035] z-0"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat',
        }}
        aria-hidden="true"
      />

      {/* Pinned 3D Spatial Stage */}
      <div
        ref={pinnedStageRef}
        className="relative z-10 w-full h-screen flex flex-col justify-center items-center px-5 sm:px-8 md:px-12 lg:px-16"
        style={{ perspective: '1600px', transformStyle: 'preserve-3d' }}
      >
        {/* Camera Spatial Planes Container for 3D Perspective shifts */}
        <div
          ref={cameraPlanesRef}
          className="relative w-full max-w-7xl h-full flex flex-col justify-center items-center"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* ══════════════════════════════════════════════════════════════════════
              SEQUENCE 1: THE OPENING STATEMENT (PHILOSOPHICAL PREMISE)
              ══════════════════════════════════════════════════════════════════════ */}
          <div
            ref={scene1Ref}
            className="scene-container w-full h-full max-h-[85vh] flex flex-col justify-between py-6 sm:py-8"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* Top Editorial Metadata Bar */}
            <div className="meta-element-1 w-full flex items-center justify-between border-b border-white/15 pb-4 text-[10px] sm:text-[11px] font-mono tracking-[0.25em] text-white/50 uppercase">
              <div className="flex items-center gap-2.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span className="font-semibold text-white/80">MANIFESTO // 02</span>
              </div>
              <div className="hidden md:flex items-center gap-4 text-white/40">
                <span>FPS: 24.00</span>
                <span>•</span>
                <span>SHUTTER: 180°</span>
                <span>•</span>
                <span>OPTIC: 35MM T1.5</span>
              </div>
              <div className="text-right tracking-[0.2em] text-white/60">
                DIRECTOR'S STATEMENT
              </div>
            </div>

            {/* Central High-Impact Typographic Body */}
            <div
              className="my-auto w-full flex flex-col gap-3 sm:gap-5 md:gap-7 py-4"
              style={{ transformStyle: 'preserve-3d' }}
            >
              {SEQUENCE_1_LINES.map((line) => {
                const isMonument = line.tier === 'monument';
                const isClimax = line.tier === 'climax';
                const isLead = line.tier === 'lead';
                const isPivot = line.tier === 'pivot';

                return (
                  <div
                    key={line.id}
                    className={`w-full flex ${
                      line.align === 'right'
                        ? 'justify-end text-right'
                        : line.align === 'between'
                        ? 'justify-between'
                        : 'justify-start text-left'
                    } overflow-hidden py-0.5`}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <div
                      className={`inline-block whitespace-nowrap overflow-visible char-${line.id}`}
                      style={{ transformStyle: 'preserve-3d' }}
                    >
                      {line.text.split('').map((char, cIdx) => (
                        <span
                          key={cIdx}
                          className={`char-outer inline-block overflow-visible ${
                            char === ' ' ? 'w-[0.34em]' : ''
                          }`}
                          style={{
                            transformStyle: 'preserve-3d',
                            willChange: 'transform, opacity',
                          }}
                        >
                          <span
                            className={`char-physics inline-block font-heading uppercase select-none ${
                              isMonument
                                ? 'font-black tracking-[-0.045em] text-white'
                                : isClimax
                                ? 'font-black tracking-[-0.035em] text-amber-300'
                                : isLead
                                ? 'font-black tracking-[-0.03em] text-white/90'
                                : isPivot
                                ? 'font-extrabold tracking-[-0.025em] text-white/75'
                                : 'font-bold tracking-[-0.02em] text-white/80'
                            }`}
                            style={{
                              fontFamily: 'var(--font-heading)',
                              fontSize: isMonument
                                ? 'clamp(54px, 12vw, 168px)'
                                : isClimax
                                ? 'clamp(28px, 5.4vw, 76px)'
                                : isLead
                                ? 'clamp(24px, 4.2vw, 58px)'
                                : isPivot
                                ? 'clamp(22px, 3.6vw, 48px)'
                                : 'clamp(20px, 3.2vw, 42px)',
                              lineHeight: isMonument ? 0.82 : 0.94,
                              willChange: 'transform',
                              transformStyle: 'preserve-3d',
                            }}
                          >
                            {char}
                          </span>
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Editorial Anchor Bar */}
            <div className="meta-element-1 w-full flex items-center justify-between border-t border-white/15 pt-4 text-[10px] sm:text-[11px] font-mono tracking-[0.22em] text-white/40 uppercase">
              <div className="flex items-center gap-2">
                <span>SCENE INDEX: 00:00:14:00</span>
                <span className="text-white/20">|</span>
                <span className="hidden sm:inline">PERSISTENCE OF VISION</span>
              </div>
              <div className="flex items-center gap-2.5 text-white/60">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span>SCROLL TO DISSOLVE REALITY</span>
              </div>
            </div>
          </div>

          {/* ══════════════════════════════════════════════════════════════════════
              SPATIAL BACKDROP GRID (DISPLAYS IN 3D FLY-THROUGH)
              ══════════════════════════════════════════════════════════════════════ */}
          <div
            ref={spatialBackdropRef}
            className="absolute inset-0 flex flex-col justify-center items-center pointer-events-none z-[-1]"
            aria-hidden="true"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="w-[85vw] max-w-5xl h-[65vh] border border-white/10 rounded-sm relative flex flex-col justify-between p-6">
              <div className="flex justify-between text-[10px] font-mono tracking-[0.3em] text-white/30">
                <span>[ SPATIAL RECONSTRUCTION ]</span>
                <span>VANISHING POINT: 0.00, 0.00</span>
              </div>
              <div className="flex justify-center items-center my-auto">
                <span className="text-[clamp(16px,2vw,28px)] font-mono font-light text-white/20 tracking-[0.4em] uppercase text-center">
                  BEYOND THE CUT • THE CINEMA OF MEMORY
                </span>
              </div>
              <div className="flex justify-between text-[10px] font-mono tracking-[0.3em] text-white/30">
                <span>DEPTH AXIS: +900MM</span>
                <span>FOCAL DISTORTION: NONE</span>
              </div>
            </div>
          </div>

          {/* ══════════════════════════════════════════════════════════════════════
              SEQUENCE 2: THE RESOLUTION (VISUAL MANIFESTO)
              Spacious, deliberate layout with intentional hierarchy & zero collision.
              ══════════════════════════════════════════════════════════════════════ */}
          <div
            ref={scene2Ref}
            className="scene-container absolute inset-0 flex flex-col justify-between items-center w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 z-20"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* Top Indicator */}
            <div className="seq2-headline flex items-center gap-3 text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.25em] text-white/50 border border-white/15 px-4 py-1.5 rounded-full bg-white/[0.03] backdrop-blur-sm">
              <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse" />
              <span>THE RESULT // CORE CINEMATIC PHILOSOPHY</span>
            </div>

            {/* Monumental Kinetic Editorial Block with Generous Line-by-Line Spacing */}
            <div
              className="flex flex-col items-center text-center font-heading font-black uppercase tracking-[-0.035em] select-none text-white my-auto w-full max-w-5xl"
              style={{
                fontFamily: 'var(--font-heading)',
                transformStyle: 'preserve-3d',
              }}
            >
              {/* LINE 1: WHAT REMAINS */}
              <div className="char-seq2-remains overflow-hidden py-1 sm:py-1.5 mb-2 sm:mb-3 md:mb-4">
                <div className="inline-block whitespace-nowrap overflow-visible">
                  {SEQUENCE_2_LINES[0].text.split('').map((char, cIdx) => (
                    <span
                      key={cIdx}
                      className={`char-outer inline-block overflow-visible ${
                        char === ' ' ? 'w-[0.34em]' : ''
                      }`}
                      style={{
                        transformStyle: 'preserve-3d',
                        willChange: 'transform, opacity',
                      }}
                    >
                      <span
                        className="char-physics inline-block font-heading font-black uppercase select-none text-white"
                        style={{
                          fontSize: 'clamp(28px, 4.8vw, 64px)',
                          lineHeight: 1.05,
                          letterSpacing: '-0.03em',
                          willChange: 'transform',
                          transformStyle: 'preserve-3d',
                        }}
                      >
                        {char}
                      </span>
                    </span>
                  ))}
                </div>
              </div>

              {/* LINE 2: WHEN THE LIGHT */}
              <div className="char-seq2-light overflow-hidden py-1 sm:py-1.5 mb-2 sm:mb-3 md:mb-4">
                <div className="inline-block whitespace-nowrap overflow-visible">
                  {SEQUENCE_2_LINES[1].text.split('').map((char, cIdx) => (
                    <span
                      key={cIdx}
                      className={`char-outer inline-block overflow-visible ${
                        char === ' ' ? 'w-[0.34em]' : ''
                      }`}
                      style={{
                        transformStyle: 'preserve-3d',
                        willChange: 'transform, opacity',
                      }}
                    >
                      <span
                        className="char-physics inline-block font-heading font-extrabold uppercase select-none text-white/80"
                        style={{
                          fontSize: 'clamp(22px, 3.8vw, 48px)',
                          lineHeight: 1.05,
                          letterSpacing: '-0.025em',
                          willChange: 'transform',
                          transformStyle: 'preserve-3d',
                        }}
                      >
                        {char}
                      </span>
                    </span>
                  ))}
                </div>
              </div>

              {/* LINE 3: FADES (Distinctive visual accent) */}
              <div className="char-seq2-fades overflow-hidden py-1 sm:py-2 mb-3 sm:mb-4 md:mb-5">
                <div className="inline-block whitespace-nowrap overflow-visible">
                  {SEQUENCE_2_LINES[2].text.split('').map((char, cIdx) => (
                    <span
                      key={cIdx}
                      className={`char-outer inline-block overflow-visible ${
                        char === ' ' ? 'w-[0.34em]' : ''
                      }`}
                      style={{
                        transformStyle: 'preserve-3d',
                        willChange: 'transform, opacity',
                      }}
                    >
                      <span
                        className="char-physics inline-block font-heading font-black uppercase select-none text-amber-300"
                        style={{
                          fontSize: 'clamp(38px, 7vw, 92px)',
                          lineHeight: 0.98,
                          letterSpacing: '-0.04em',
                          willChange: 'transform',
                          transformStyle: 'preserve-3d',
                        }}
                      >
                        {char}
                      </span>
                    </span>
                  ))}
                </div>
              </div>

              {/* LINE 4: IS THE EMOTION. (The Dramatic Focal Climax — Zero Collision) */}
              <div className="char-seq2-emotion overflow-hidden py-1 sm:py-2">
                <div className="inline-block whitespace-nowrap overflow-visible">
                  {SEQUENCE_2_LINES[3].text.split('').map((char, cIdx) => {
                    const isDot = char === '.';
                    return (
                      <span
                        key={cIdx}
                        className={`char-outer inline-block overflow-visible ${
                          char === ' ' ? 'w-[0.34em]' : ''
                        }`}
                        style={{
                          transformStyle: 'preserve-3d',
                          willChange: 'transform, opacity',
                        }}
                      >
                        <span
                          className={`char-physics inline-block font-heading font-black uppercase select-none ${
                            isDot ? 'text-amber-400 font-black' : 'text-white'
                          }`}
                          style={{
                            fontSize: 'clamp(36px, 7.5vw, 105px)',
                            lineHeight: 0.92,
                            letterSpacing: '-0.045em',
                            willChange: 'transform',
                            transformStyle: 'preserve-3d',
                          }}
                        >
                          {char}
                        </span>
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Final Statement Quote & Director Attribution */}
            <div className="w-full max-w-2xl flex flex-col items-center text-center border-t border-white/15 pt-4 sm:pt-5">
              <p className="seq2-quote text-white/85 text-[14px] sm:text-[16px] md:text-[18px] font-body font-light italic leading-relaxed tracking-wide">
                &ldquo;I don't just want to tell stories. I want to create experiences that stay long after the frame disappears.&rdquo;
              </p>

              <div className="seq2-attribution mt-2.5 flex items-center gap-3 text-white/60 font-mono text-[10px] sm:text-[11px] tracking-[0.25em] uppercase">
                <span className="w-1.5 h-1.5 bg-amber-400 rounded-full" />
                <span>AAHAN VASUDEV // DIRECTOR ETHOS</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
