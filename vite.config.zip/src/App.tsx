import React, { useRef } from 'react';
import { BackgroundVideo, BackgroundVideoHandle } from './components/BackgroundVideo';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { HeroTransition } from './components/HeroTransition';
import { IntroStatement } from './components/sections/IntroStatement';
import { ProjectsShowreel } from './components/sections/ProjectsShowreel';
import { BehindTheScenes } from './components/sections/BehindTheScenes';
import { SectionPlaceholder } from './components/sections/SectionPlaceholder';

export const App: React.FC = () => {
  const videoRef = useRef<BackgroundVideoHandle | null>(null);
  const videoWrapperRef = useRef<HTMLDivElement | null>(null);

  return (
    <div className="relative w-full bg-black select-none font-body">
      {/* Background Video — fixed behind everything with horizontal scrub */}
      <BackgroundVideo
        ref={(handle) => {
          if (handle) {
            // Keep a stable ref to the wrapper for GSAP scaling
            videoWrapperRef.current = handle.wrapperElement;
          }
          (videoRef as React.MutableRefObject<BackgroundVideoHandle | null>).current = handle;
        }}
      />

      {/* Fixed Navbar with desktop links and mobile hamburger overlay */}
      <Navbar />

      {/* ═══════════════════════════════════════════════
          SCROLL CONTAINER — CINEMATIC FLOW
          ═══════════════════════════════════════════════ */}

      {/* Hero section with unified, pinned cinematic scene transition */}
      <HeroTransition videoWrapperRef={videoWrapperRef}>
        <Hero />
      </HeroTransition>

      {/* Phase 2: Introduction Statement */}
      <IntroStatement />

      {/* Phase 3: Film Projects Showreel */}
      <ProjectsShowreel />

      {/* Phase 4: Behind The Scenes Documentary Archive */}
      <BehindTheScenes />

      {/* Architectural placeholders for remaining sections */}
      <SectionPlaceholder id="about" title="About Me" />
      <SectionPlaceholder id="contact" title="Contact" />
    </div>
  );
};

export default App;
