/**
 * ============================================================================
 * FILM PROJECTS SHOWREEL DATA
 * ============================================================================
 * Centralized data source for your personal filmmaker portfolio.
 *
 * TO EDIT OR ADD PROJECTS:
 * - Update, duplicate, or delete items in the `PROJECTS_DATA` array below.
 * - All fields except `id` and `title` are OPTIONAL.
 * - The UI automatically adapts based on which fields are populated.
 * - Replace `thumbnailUrl` with your actual film stills, poster art, or screenshots.
 * - Add YouTube, Vimeo, or direct MP4 links to `videoUrl` for playable modal showreels.
 */

export interface ProjectCredit {
  label: string;
  value: string;
}

export interface FilmProject {
  id: string;
  title: string;
  subtitle?: string;
  year?: string;
  category?: string;
  role?: string;
  duration?: string;
  aspectRatio?: string; // e.g. "2.39:1", "16:9", "1.85:1", "4:3"
  description?: string;
  credits?: ProjectCredit[];
  thumbnailUrl?: string;
  videoUrl?: string; // YouTube, Vimeo, or direct video URL
  awards?: string[];
  accentColor?: string;
}

export const PROJECTS_DATA: FilmProject[] = [
  {
    id: 'project-01',
    title: '[PROJECT 01: TITLE PLACEHOLDER]',
    subtitle: 'Narrative Short Film',
    year: '2025',
    category: 'NARRATIVE SHORT',
    role: 'Writer, Director & Editor',
    duration: '14 MIN',
    aspectRatio: '2.39:1',
    description:
      '[Replace with your project synopsis. Example: An intimate study of temporal displacement and emotional resonance, captured on 35mm anamorphic lenses amidst the misty highlands.]',
    credits: [
      { label: 'Director', value: '[Your Name]' },
      { label: 'Cinematographer', value: '[Cinematographer Name]' },
      { label: 'Sound Design', value: '[Sound Designer Name]' },
      { label: 'Colorist', value: '[Colorist Name]' },
    ],
    // High-resolution cinematic atmospheric placeholder still
    thumbnailUrl:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=1920&q=80',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', // Optional: click opens full-screen cinematic player
    awards: ['OFFICIAL SELECTION // FESTIVAL 2025', 'BEST CINEMATOGRAPHY NOMINEE'],
  },
  {
    id: 'project-02',
    title: '[PROJECT 02: TITLE PLACEHOLDER]',
    subtitle: 'Cinematic Fashion & Visual Piece',
    year: '2024',
    category: 'BRANDED FILM / VISUAL POEM',
    role: 'Director & Creative Director',
    duration: '03:45',
    aspectRatio: '16:9',
    description:
      '[Replace with your project synopsis. Example: A kinetic convergence of light, choreography, and brutalist architecture crafted for an avant-garde runway label.]',
    credits: [
      { label: 'Director', value: '[Your Name]' },
      { label: 'Producer', value: '[Producer Name]' },
      { label: 'Director of Photography', value: '[DP Name]' },
      { label: 'Editor', value: '[Editor Name]' },
    ],
    thumbnailUrl:
      'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=1920&q=80',
    videoUrl: 'https://vimeo.com/76979871',
    awards: ['VIMEO STAFF PICK CANDIDATE'],
  },
  {
    id: 'project-03',
    title: '[PROJECT 03: TITLE PLACEHOLDER]',
    subtitle: 'Independent Feature Doc',
    year: '2024',
    category: 'DOCUMENTARY FEATURE',
    role: 'Co-Director & Cinematographer',
    duration: '78 MIN',
    aspectRatio: '1.85:1',
    description:
      '[Replace with your project synopsis. Example: A five-year observational chronicle documenting subterranean artisans in post-industrial harbor districts.]',
    credits: [
      { label: 'Co-Director', value: '[Your Name]' },
      { label: 'Lead DP', value: '[Your Name]' },
      { label: 'Original Score', value: '[Composer Name]' },
      { label: 'Executive Producer', value: '[Studio / Producer]' },
    ],
    thumbnailUrl:
      'https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?auto=format&fit=crop&w=1920&q=80',
    awards: ['AUDIENCE CHOICE AWARD // DOC FEST'],
  },
  {
    id: 'project-04',
    title: '[PROJECT 04: TITLE PLACEHOLDER]',
    subtitle: 'Experimental Music Film',
    year: '2023',
    category: 'MUSIC & AUDIOVISUAL',
    role: 'Director, Camera & VFX',
    duration: '05:12',
    aspectRatio: '4:3',
    description:
      '[Replace with your project synopsis. Example: An analog synthesizer soundscape rendered into surreal optical distortion using vintage prism glass and infrared film emulsions.]',
    credits: [
      { label: 'Direction & VFX', value: '[Your Name]' },
      { label: 'Artist', value: '[Musical Artist / Band]' },
      { label: 'Gaffer', value: '[Gaffer Name]' },
    ],
    thumbnailUrl:
      'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1920&q=80',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  },
];
